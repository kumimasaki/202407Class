package ec.com.models.dto;

import lombok.Data;

@Data
public class AdminDto {
	private Long adminId;
    private String adminEmail;
    private String adminName;
}