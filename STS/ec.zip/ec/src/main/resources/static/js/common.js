$(function () {
    $(".menu-toggle_btn").on('click', function () {
        $(this).toggleClass('active');
        $('.menu-inner').toggleClass('active');
        $('menu__item').toggleClass('active');
    });

});