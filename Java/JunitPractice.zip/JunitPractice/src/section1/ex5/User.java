package section1.ex5;

public class User {
    private String username;

    // コンストラクタ
    public User(String username) {
        this.username = username;
    }

    // ユーザー名を取得するメソッド
    public String getUsername() {
        return username;
    }
	
	public static void main(String[] args) {
	}
}